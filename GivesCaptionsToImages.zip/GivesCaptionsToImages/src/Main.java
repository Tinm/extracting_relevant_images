// put this progam on your computer and run it specifing the direcories that you want to use

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


public class Main {
   public static ArrayList<String> jsonContents = new ArrayList<String>();
   public static ArrayList<String> imgLabes = new ArrayList<String>();
   public static String foodLable = "   \"label\" : \"food\" ";
   public static String drinkLable = "   \"label\" : \"drink\" ";
   public static String insideLable = "   \"label\" : \"inside\" ";
   public static String outsideLable = "   \"label\" : \"outside\" ";
   public static String menuLable = "   \"label\" : \"menu\" ";
   
   public static void main(String args[]) throws IOException
   {
	 
	   //READ IN JSON AND MAKE ARRAY LIST OF IT
	   ///home/tinm/Desktop/DataMiningTest/capTest.json
	   String newLabeltion = "KILLME";
	   Scanner s = new Scanner(new File("/home/tinm/Desktop/DataMiningTest/capTest.json"));
	   
	   while (s.hasNextLine()){
	       jsonContents.add(s.nextLine());
	   }
	   s.close();
	   //print array list
	   for(int i = 0; i < jsonContents.size(); i++) {   
		    //System.out.println(jsonContents.get(i));
		}  
	   //DONE WITH READING IN ARRAY LIST
	   
	   
	  //Read in IMAGES WTH LABLES AND ARRAY LISt
	   Scanner s2 = new Scanner(new File("/home/tinm/Desktop/DataMiningTest/imgWithLabels.txt"));
	   
	   while (s2.hasNextLine()){
	       imgLabes.add(s2.nextLine());
	   }
	   s2.close();
	   //print array list
	   /*for(int i = 0; i < imgLabes.size(); i++) {
		   String newLabel = imgLabes.get(i);
		   newLabel = newLabel.replace(".jpg", "");
		   imgLabes.set( i, newLabel );	
		   //System.out.println(imgLabes.get(i));
		}*/
	   //INSERTING INTO JSON
	   for(int i = 0; i < imgLabes.size(); i++) {
		   if(imgLabes.get(i).contains("Food")){
			   String id = imgLabes.get(i);
			   //System.out.println(id);
			   id = id.substring(0,22);
			   //System.out.println(id);
			   lookForLabelInJson(i,id,foodLable);
		   }
		   if(imgLabes.get(i).contains("Drinks")){
			   String id = imgLabes.get(i);
			   //System.out.println(id);
			   id = id.substring(0,22);
			   //System.out.println(id);
			   lookForLabelInJson(i,id,drinkLable);
		   }
		   if(imgLabes.get(i).contains("Inside")){
			   String id = imgLabes.get(i);
			   //System.out.println(id);
			   id = id.substring(0,22);
			   //System.out.println(id);
			   lookForLabelInJson(i,id,insideLable);
		   }
		   if(imgLabes.get(i).contains("Outside")){
			   String id = imgLabes.get(i);
			   //System.out.println(id);
			   id = id.substring(0,22);
			   //System.out.println(id);
			   lookForLabelInJson(i,id,outsideLable);
		   }
		   if(imgLabes.get(i).contains("Menu")){
			   String id = imgLabes.get(i);
			   //System.out.println(id);
			   id = id.substring(0,22);
			   //System.out.println(id);
			   lookForLabelInJson(i,id,menuLable);
		   }  
		}
	   for(int i = 0; i < jsonContents.size(); i++) {   
		    System.out.println(jsonContents.get(i));
		}  
	   
	   write ();
	   
   }
   
   public static void lookForLabelInJson(int pos, String id, String lab){
	   for(int j = 0; j < jsonContents.size(); j++) {
		    if(jsonContents.get(j).contains(id)){
		    	jsonContents.set(j+2, lab);
		    	break;
		    }
		    
		}  
	   
   }
   
  //write
   public static void write () throws IOException{
	   BufferedWriter outputWriter = null;
	   outputWriter = new BufferedWriter(new FileWriter("/home/tinm/Desktop/DataMiningTest/jsonWithLabels.json"));
	   for(int i = 0; i < jsonContents.size(); i++){
	     // Maybe:
	     outputWriter.write(jsonContents.get(i));
	     outputWriter.newLine();
	   }
	   outputWriter.flush();  
	   outputWriter.close();  
	 }
   
   
   
   
   
   
}