// put this progam on your computer and run it specifing the direcories that you want to use

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


public class Main {
   public static void main(String args[]) throws IOException
   {
	   //THIS IS THE JSON THAT HAS ALL THE RESTAURANT IDS
	   String restaraunts = "/home/tinm/Desktop/DataMiningTest/newCaptions.json";
	   ArrayList<String> restaurantList = new ArrayList<String>();
	   try (BufferedReader br = new BufferedReader(new FileReader(restaraunts))) {
			String line;
			String sub = new String();
			while ((line = br.readLine()) != null) {
				if(line.contains("photo_id")){
					//System.out.println(line);
					sub = line.substring(16, 38);
					sub = sub.concat(".jpg");
					restaurantList.add(sub);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	   System.out.println("-------------------------");
	   /*for(int i=0;i<restaurantList.size();i++){
		    System.out.println(restaurantList.get(i));
		}*/ 
	   
	   //gets the names of the images in the folder
	   System.out.println("IMAGE IN FOLDER NAMES");
	   //DIRECTORY WITH ALL IMAGES
	   File folder = new File("/home/tinm/Desktop/DataMiningTest/yelpImages");
	   File[] listOfFiles = folder.listFiles();
	   //THIS IS THE FOLDER WITH ALL THE IMAGES IN IT MAKE SURE IT ENDS IN /
	   String srcDir = "/home/tinm/Desktop/DataMiningTest/yelpImages/";
	   //MAKE AN EMPTY DIRCTORY AND NAME IT HERE MAKE SURE IT ENDS IN /
	   String destDir = "/home/tinm/Desktop/DataMiningTest/restImages/";
	   String srcName;
	   String destName;
	   for (int i = 0; i < listOfFiles.length; i++) {
		   if (listOfFiles[i].isFile()) {
			   //System.out.println("File " + listOfFiles[i].getName());
			   for(int j=0;j<restaurantList.size();j++){
				    if(restaurantList.get(j).equals(listOfFiles[i].getName())){
				    	//System.out.println(restaurantList.get(j));
				    	srcName = srcDir.concat(restaurantList.get(j));
				    	destName = destDir.concat(restaurantList.get(j));
				    	System.out.println(srcName);
				    	System.out.println(destName);
				    	Files.move(Paths.get(srcName), Paths.get(destName));
				    }
				} 
		   } 
	    }
	   
	   
	   
   }
}