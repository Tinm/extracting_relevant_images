import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ReviewToPhotoMapper {
	JSONReader photoReader, reviewReader;
	String[] keyTerms;
	Map<String, Map<String, List<String>>> photoBucket;
	Map<String, Set<String>> reviewMap;
	List<JSONObject> reviews;
	
	public ReviewToPhotoMapper(String photoJSON, String reviewJSON, String[] keyTerms) {
		photoReader = new JSONReader(photoJSON);
		reviewReader = new JSONReader(reviewJSON);
		this.keyTerms = keyTerms;
	}
	
	public void generateMapping() {
		//Step 1: Store photos in buckets
		photoBucket = generatePhotoBuckets();
		
		//Step 2: Iterate over all reviews & map to photos
		reviewMap = mapReviewsToPhotos();
		
		//Step 3: Output results to file
		//It is in form: business_id user_id photo_id0 photo_id1 .. photo_idN
		outputResultsToFile(reviewMap);
	}

	private void outputResultsToFile(Map<String, Set<String>> rm) {
		Iterator<String> iter = rm.keySet().iterator();
		PrintWriter pw =  null;
		try {
			pw =  new PrintWriter(new File("review_to_photos_map.txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(-1);
		}
		while(iter.hasNext()) {
			String currentKey = iter.next();
			Set<String> photos = rm.get(currentKey);
			
			StringBuilder sb = new StringBuilder();
			sb.append(currentKey + " ");
			for(String p : photos) {
				sb.append(p + " ");
			}
			pw.println(sb.toString());
		}
		pw.close();
	}

	private Map<String, Set<String>> mapReviewsToPhotos() {
		reviews = reviewReader.getReviewData();
		
		Map<String, Set<String>> finalReviewMap = new HashMap<>();
		
		for(JSONObject review : reviews) {
			String businessId = null;
			String reviewText = null;
			String reviewId = null;
			String reviewTokens[] = null;
			try {
				businessId = review.getString("business_id");
				reviewId = review.getString("review_id");
				reviewText = review.getString("text");
				reviewText = reviewText.replaceAll("[^\\w\\s]+", "");
				reviewText = reviewText.replaceAll("[ ]+", " ");
				reviewText = reviewText.toLowerCase();
				reviewTokens = reviewText.split(" ");
			} catch (JSONException e) {
				System.out.println("Review missing field. Skipping review...");
				continue;
			}
			
			if(!photoBucket.containsKey(businessId)) {
				photoBucket.put(businessId, new HashMap<>());
			}
			
			Map<String, List<String>> termMap = photoBucket.get(businessId);
			finalReviewMap.put(reviewId, new HashSet<String>());
			
			for(String token : reviewTokens) {
				if(termMap.containsKey(token)) {
					List<String> relatedPhotos = termMap.get(token);
					for(String photo : relatedPhotos) {
						finalReviewMap.get(reviewId).add(photo);
					}
				}
			}
		}
		return finalReviewMap;
	}

	private Map<String, Map<String, List<String>>> generatePhotoBuckets() {
		Map<String, Map<String, List<String>>> photoBucket = new HashMap<>();
		JSONArray photos = photoReader.getPhotoData();
		
		for(int i = 0; i < photos.length(); i++) {
			JSONObject current = null;
			String businessId = null, 
					caption = null,
					photoId = null;
			String[] captions = null;
			
			try {
				
				current = photos.getJSONObject(i);
				businessId = current.getString("business_id");
				caption = current.getString("CAPTION");
				photoId = current.getString("photo_id");
				
				caption = caption.replaceAll("[^\\w\\s]+", "");
				caption = caption.replaceAll("[ ]+", " ");
				caption = caption.toLowerCase();
				captions = caption.split(" ");
			} catch (JSONException e) {
				e.printStackTrace();
				System.exit(-1);
			}
			
			if(!photoBucket.containsKey(businessId)) {
				photoBucket.put(businessId, new HashMap<>());
			}
			
			for(String termA : keyTerms) {
				for(String termB : captions) {
					if(termA.equals(termB)) {
						Map<String, List<String>> bucket = photoBucket.get(businessId);
						
						if(!bucket.containsKey(termA)) {
							bucket.put(termA, new LinkedList<String>());
						}
						bucket.get(termA).add(photoId);
					}
				}
			}
		}
		return photoBucket;
	}
}
