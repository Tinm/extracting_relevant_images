import java.util.Arrays;

public class Main {

	public static void main (String[] args){
		
		if(args.length == 0) {
			System.out.println("Need parameters OPERATION and ARGS");
			System.exit(-1);
		}
		
		String function = args[0].toLowerCase();
		
		if(function.equals("frequency") &&
				args.length == 2) {
			System.out.println("Generating frequency.txt...");
			FrequencyComputer computer = new FrequencyComputer(args[1]);
			computer.generateFrequencyFile();
		} else if(function.equals("categorize") &&
				args.length == 3) {
			System.out.println("Categorizing Images: ");
			ImageCategorizer reader = new ImageCategorizer(args[1], args[2]);
			reader.categorize();
		} else if (function.equals("reviewmap") && 
				args.length >= 4) {
			System.out.println("Mapping reviews to photos: ");
			ReviewToPhotoMapper mapper = new ReviewToPhotoMapper(args[1],
					args[2], Arrays.copyOfRange(args, 3, args.length));
			mapper.generateMapping();
		} else {
			System.out.println("Need parameters OPERATION and ARGS");
			System.exit(-1);
		}
		System.out.println("Operation Complete!");
		
		
	}
}
