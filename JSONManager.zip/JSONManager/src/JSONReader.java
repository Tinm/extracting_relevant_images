import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class JSONReader {
	
	private String json;
	
	public JSONReader(String json) {
		this.json = json;
	}

	public JSONArray getPhotoData() {
		File stream = new File(json);
		String text = null;
		StringBuilder sb = new StringBuilder();
		
		try {
			
			BufferedReader reader = new BufferedReader(new FileReader(stream));
			
			while((text = reader.readLine()) != null)
			{
				sb.append(text);
			}
			reader.close();
			
		} catch(Exception e) {
			System.out.println("Unable to find the captions file. Closing...");
			e.printStackTrace();
			System.exit(-1);
		}

		JSONArray photo = null;
		try {
			JSONObject object = new JSONObject(sb.toString());
			JSONObject photos = (JSONObject) object.get("photos");
			photo = (JSONArray)photos.getJSONArray("photo");
		} catch (Exception e) {
			System.out.println("Issue processing JSON File. Closing...");
			e.printStackTrace();
			System.exit(-2);
		}
		return photo;
	}
	
	public List<JSONObject> getReviewData() {
		List<JSONObject> returnedList = new ArrayList<JSONObject>();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(json), "UTF-8"));
			
			int charAsInt = reader.read();
			StringBuilder sb = new StringBuilder();
			int curlyBraces = 0;
			while(charAsInt != -1) {
				char current = (char)charAsInt;
				
				switch(current) {
				case '{':
					curlyBraces++;
					break;
				case '}':
					curlyBraces--;
					break;
				default:
					break;
				}
				sb.append(current);
				
				if(curlyBraces == 0 && sb.length() > 0) {
					String cleanedJSON = sb.toString();
					if(cleanedJSON.replaceAll("\\s+", "").length() != 0) {
						try {
							//System.out.println(cleanedJSON);
							JSONObject object = new JSONObject(cleanedJSON);
							returnedList.add(object);
						} catch (Exception e) {
							//System.out.println("Error with next token. Skipping...");
						}
					}
					sb.setLength(0);
				}
				charAsInt = reader.read();
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		} 
		return returnedList;
	}
}
