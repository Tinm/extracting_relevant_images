
import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.json.*;

public class ImageCategorizer  {
	
	private String sourceImages;
	private JSONReader reader;
	
	public ImageCategorizer(String json, String sourceImages){
		reader = new JSONReader(json);
		this.sourceImages = sourceImages;
	}
	
	public void categorize()
	{
		
		JSONArray photo = reader.getPhotoData();
		PrintWriter errorWriter = null;
		
		try{
			errorWriter = new PrintWriter(new File("categorizer_errors.txt"));
		}
		catch(Exception e){
			
		}
		
		for (int i = 0; i < photo.length(); i++) {
			JSONObject record = null;
			File dir = null;
			Path src = null, target = null;
			
			try {
				
				record = photo.getJSONObject(i);
				
				dir = new File("CategorizedImages\\" + record.get("label"));
				
				//check if folder exists and if it doesnt create it 
				if(!dir.exists())
				{
					dir.mkdir();
				}
				
				//Set up source and target paths
				src = Paths.get(sourceImages + "\\" + record.getString("photo_id") + ".jpg");
				target = Paths.get("CategorizedImages\\" + record.get("label") 
					+ "\\" + record.getString("photo_id") + ".jpg");
				
			} catch (Exception e) {
				System.out.println("Issue processing JSON at index " + i + ". Continuing...");
				errorWriter.println("Issue with JSONObject at index " + i);
				continue;
			}
			
			//copy image to folder
			try {
				System.out.println("Copying file " + src.toString() + "...");
				Files.copy(src,  target, StandardCopyOption.REPLACE_EXISTING);
				System.out.println("Copied file!");
			} catch (Exception e) {
				System.out.println("Issue copying file " + src.toString() + ". Perhaps it does " +
						"not exist? Continuing...");
				errorWriter.println("Issue copying file " + src.toString());
			}
		}
		if(errorWriter != null) {
			errorWriter.close();
		}
	}
}
