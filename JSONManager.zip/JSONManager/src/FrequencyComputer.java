import java.io.File;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

import org.json.JSONArray;
import org.json.JSONObject;

public class FrequencyComputer {

	private JSONReader reader;
	
	public FrequencyComputer(String json){
		reader = new JSONReader(json);
	}
	
	public void generateFrequencyFile()
	{
		JSONArray photo = reader.getPhotoData();
		
		Map<String,Integer> frequencyMap = new HashMap<String,Integer>();
		
		for (int i = 0; i < photo.length(); i++) {
			JSONObject record = null;
			
			try {
				
				record = photo.getJSONObject(i);
				
			} catch (Exception e) {
				System.out.println("Issue processing JSON at index " + i + ". Continuing...");
				continue;
			}
			
			String caption = null;
			
			try {
				caption = record.getString("CAPTION");
			} catch(Exception e) {
				System.out.println("Issue processing JSON at index " + i + ". Continuing...");
				continue;
			}

			caption = caption.replaceAll("[^\\w\\s]+", "");
			caption = caption.replaceAll("[ ]+", " ");
			caption = caption.toLowerCase();
			
			StringTokenizer tokenizer = new StringTokenizer(caption);
			
			while(tokenizer.hasMoreTokens()){
				String token = tokenizer.nextToken();
				
				if(	!frequencyMap.containsKey(token)){
					frequencyMap.put(token, 0);
				}
				
				int previousCount = frequencyMap.get(token);
				frequencyMap.put(token, previousCount + 1);
			}
		}
		
		Iterator<String> iter = frequencyMap.keySet().iterator();
		PriorityQueue<WordCounter> pqueue = new PriorityQueue<WordCounter>();
		
		while(iter.hasNext()){
			String word = iter.next();
			int count = frequencyMap.get(word);
			WordCounter wCounter = new WordCounter(word,count);
			pqueue.add(wCounter);
		}
		
		PrintWriter file = null;
		try {
			file = new PrintWriter(new File("frequency.txt"));
		} catch (Exception e) {
			System.out.println("Unable to generate frequency.txt. Exiting...");
			System.exit(-3);
		}
		
		while(!pqueue.isEmpty()){
			WordCounter wCounter = pqueue.poll();
			file.println(wCounter.toString());
		}
		file.close();
	}

	private class WordCounter implements Comparable <WordCounter>{
		
		String word;
		int count;
		public WordCounter(String word, int count){
			this.word = word;
			this.count= count;
		}
		
		@Override
		public int compareTo(WordCounter otherCount) {
			return otherCount.count - count;
		}
		@Override
		public String toString(){
			return word + "," + count;
		}
	}
}
