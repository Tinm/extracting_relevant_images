-FrequencyComputer keeps track of the key term count within the captions of the JSON object 
and creates a file that displays the results
-ImageCategorizer categorizes images into separate folders based off labels. If a folder of a  photo's 
label field doesn't already exist, it creates a folder with the same name as label. If it does, it copies
the image into the corresping folder (based off the photo id) from the source folder to the newly generated
destination folder. 
-JSONReader reads the JSON objects 
-ReviewToPhotoMapper creates a file with the review id as the first column and the appended photos as the following columns 
depending on how many photos mapped to the review (if any)
-LaunchJSONManager is the batch file 